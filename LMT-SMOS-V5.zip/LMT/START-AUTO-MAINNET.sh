#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"

"$DIR/lumenite-gpu-miner" \
  --backend auto \
  "$@"
