Lumenite HomeScrypt GPU Miner v1.2.0
CUDA 12 Linux x86_64 Release

Algorithm:
  HomeScrypt v1.2

Official Pool:
  kcminers.com:3333

Included:
  lumenite-gpu-miner
  homescrypt_cuda_miner
  homescrypt_opencl_miner
  homescrypt_opencl.cl
  Linux start scripts

Console:
  Clean status display refreshes approximately every 3 seconds.
  Mining/hash execution is NOT throttled by the display.

Edit the appropriate start script and replace the example
wallet/worker with your own Lumenite address and worker name.
