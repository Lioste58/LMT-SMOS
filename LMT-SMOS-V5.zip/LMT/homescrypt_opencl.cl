#pragma OPENCL EXTENSION cl_khr_int64_base_atomics : enable

#define SCRATCHPAD_BYTES (16UL * 1024UL * 1024UL)
#define WORDS (SCRATCHPAD_BYTES / 8UL)
#define RANDOM_MIX_ROUNDS (WORDS / 32UL)
#define FP_PASSES 6
#define FP_INNER 8

inline ulong rotl64_hs(ulong x, uint r)
{
    return (x << r) | (x >> (64U - r));
}

inline ulong load64le_hs(__global const uchar *p)
{
    return ((ulong)p[0]) |
           ((ulong)p[1] << 8) |
           ((ulong)p[2] << 16) |
           ((ulong)p[3] << 24) |
           ((ulong)p[4] << 32) |
           ((ulong)p[5] << 40) |
           ((ulong)p[6] << 48) |
           ((ulong)p[7] << 56);
}

inline ulong avalanche_hs(ulong x)
{
    x ^= x >> 30;
    x *= (ulong)0xbf58476d1ce4e5b9UL;
    x ^= x >> 27;
    x *= (ulong)0x94d049bb133111ebUL;
    x ^= x >> 31;
    return x;
}

inline uint f32_bits_hs(float f)
{
    return as_uint(f);
}

inline float bits_f32_hs(uint w)
{
    return as_float(w);
}

inline float safe_f32_hs(uint w)
{
    const uint exp = 118U + ((w >> 23) & 0x0FU);
    return bits_f32_hs((exp << 23) | (w & 0x007FFFFFU));
}

__kernel void homescrypt_memory_kernel(
    __global const uchar *seeds,
    __global ulong *scratch,
    __global uchar *folded_out,
    const int jobs)
{
    const int job = (int)get_global_id(0);

    if (job >= jobs)
        return;

    __global const uchar *seed = seeds + ((size_t)job * 32);
    __global ulong *sp = scratch + ((size_t)job * WORDS);

    ulong state[4];

    state[0] = load64le_hs(seed);
    state[1] = load64le_hs(seed + 8);
    state[2] = load64le_hs(seed + 16);
    state[3] = load64le_hs(seed + 24);

    ulong x =
        state[0] ^
        rotl64_hs(state[1], 17) ^
        rotl64_hs(state[2], 31) ^
        rotl64_hs(state[3], 47);

    for (size_t i = 0; i < WORDS; ++i) {
        x += (ulong)0x9e3779b97f4a7c15UL + (ulong)i;
        x ^= state[i & 3] +
             rotl64_hs(x, (uint)((i & 31) + 1));
        x = avalanche_hs(x);
        sp[i] = x;
        state[i & 3] ^=
            x + rotl64_hs(state[(i + 1) & 3], 23);
    }

    for (size_t round = 0;
         round < RANDOM_MIX_ROUNDS;
         ++round) {

        const size_t lane = round & 3;

        const size_t idx1 =
            (size_t)(state[lane] ^ x ^ (ulong)round) &
            (WORDS - 1);

        const ulong a = sp[idx1];

        const size_t idx2 =
            (size_t)(a ^
                rotl64_hs(state[(lane + 1) & 3], 17)) &
            (WORDS - 1);

        const ulong b = sp[idx2];

        const size_t idx3 =
            (size_t)(b ^
                rotl64_hs(a, 31) ^
                state[(lane + 2) & 3]) &
            (WORDS - 1);

        const ulong c = sp[idx3];

        const ulong mixed =
            a +
            rotl64_hs(b, 23) +
            rotl64_hs(c, 41) +
            state[(lane + 3) & 3] +
            (ulong)round;

        float m0 = safe_f32_hs((uint)(c >> 32));
        float m1 = safe_f32_hs((uint)c);
        float m2 = safe_f32_hs((uint)(mixed >> 32));
        float m3 = safe_f32_hs((uint)mixed);

        float g0 = safe_f32_hs((uint)(a >> 32));
        float g1 = safe_f32_hs((uint)a);
        float g2 = safe_f32_hs((uint)(b >> 32));
        float g3 = safe_f32_hs((uint)b);

        for (size_t pass = 0; pass < FP_PASSES; ++pass) {
            for (int j = 0; j < FP_INNER; ++j) {
                g0 = fma(g0, m0, g3);
                g1 = fma(g1, m1, g0);
                g2 = fma(g2, m2, g1);
                g3 = fma(g3, m3, g2);
            }

            const uint w0 = f32_bits_hs(g0);
            const uint w1 = f32_bits_hs(g1);
            const uint w2 = f32_bits_hs(g2);
            const uint w3 = f32_bits_hs(g3);

            g0 = safe_f32_hs(w0);
            g1 = safe_f32_hs(w1);
            g2 = safe_f32_hs(w2);
            g3 = safe_f32_hs(w3);

            const float t = m0;
            m0 = safe_f32_hs(f32_bits_hs(m1) ^ w0);
            m1 = safe_f32_hs(f32_bits_hs(m2) ^ w1);
            m2 = safe_f32_hs(f32_bits_hs(m3) ^ w2);
            m3 = safe_f32_hs(f32_bits_hs(t) ^ w3);
        }

        const ulong fp =
            (((ulong)f32_bits_hs(g0) << 32) |
              (ulong)f32_bits_hs(g1))
            ^
            rotl64_hs(
                ((ulong)f32_bits_hs(g2) << 32) |
                (ulong)f32_bits_hs(g3),
                29);

        state[lane] ^= mixed ^ fp;

        state[lane] =
            rotl64_hs(
                state[lane],
                (uint)((mixed & 31) + 1));

        state[(lane + 1) & 3] +=
            a ^ rotl64_hs(c, 13);

        sp[idx1] =
            a ^
            state[lane] ^
            rotl64_hs(c, 7);

        sp[idx2] =
            b +
            state[(lane + 1) & 3] +
            rotl64_hs(a, 19);

        sp[idx3] =
            c ^
            mixed ^
            rotl64_hs(b, 37);

        x =
            rotl64_hs(
                x ^ mixed ^ fp ^ sp[idx3],
                29);
    }

    ulong f0 = state[0];
    ulong f1 = state[1];
    ulong f2 = state[2];
    ulong f3 = state[3];

    for (size_t i = 0; i < WORDS; i += 4) {
        f0 = avalanche_hs(f0 ^ sp[i]);
        f1 = avalanche_hs(f1 + sp[i + 1]);
        f2 = avalanche_hs(
            f2 ^ rotl64_hs(sp[i + 2], 17));
        f3 = avalanche_hs(
            f3 + rotl64_hs(sp[i + 3], 41));
    }

    __global uchar *o =
        folded_out + ((size_t)job * 32);

    for (int k = 0; k < 8; ++k) {
        o[k]      = (uchar)(f0 >> (8 * k));
        o[8 + k]  = (uchar)(f1 >> (8 * k));
        o[16 + k] = (uchar)(f2 >> (8 * k));
        o[24 + k] = (uchar)(f3 >> (8 * k));
    }
}
